<?php
$videoId = $videoInfo->videoId;
$title = $videoInfo->title;
$image_url = $videoInfo->image_url;
$video_url = $videoInfo->video_url;
$status = $videoInfo->status;

?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Video Management
        <small>Add / Edit Video</small>
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary">
                    <div class="box-header">
                        <h3 class="box-title">Enter Video Details</h3>
                    </div><!-- /.box-header -->
                    <!-- form start -->                    
                   <form role="form" id="editVideo" enctype="multipart/form-data" action="<?php echo base_url() ?>editVideo" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="title">Title</label>
										<input type="hidden" value="<?php echo $videoId; ?>" name="videoId" id="videoId" />    
                                        <input type="text" class="form-control required" value="<?php echo $title; ?>" id="title" name="title" maxlength="128">
                                    </div>                                    
                                </div>   
  								 <div class="col-md-4">                                
                                    <div class="form-group">
                                        <label for="title">Thumb Image</label>										
                                        <input accept="image/*" type="file" class="form-control required" value="<?php echo $image_url; ?>" id="thumb" name="thumb">										
										
                                    </div>  
<script>
thumb.onchange = evt => {
  const [file] = thumb.files
  if (file) {
    blah.src = URL.createObjectURL(file)
    blahlink.href = URL.createObjectURL(file)
  }
}
</script>									
                                </div> 
<a id="blahlink" href="" target="_blank"><img id="blah" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAOEAAADhCAMAAAAJbSJIAAAAJ1BMVEXt7e3V1dXW1tbm5ubs7Ozg4ODc3NzS0tLw8PDo6OjZ2dnj4+Pe3t5T9WAhAAAEmklEQVR4nO2ciXKsIBBFsQUB9f+/9+EuKjPEpe2X3FOVSTJlAmdaWRpUKQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP8Pbnh9mr4Uza+nnSpbChTTy0M/hNfKeNeXyIshW/BReaVZ4+h8zSY3lESG008rz+a30LIqFpbYDa1huxC1qovQDHAbUuG5DF3Tl8cmORdTs/Ua9VxuzUHXaA+WnsnQD90EUa1ZPlRtChoMuRobs5w0PLiGphJ5YlgNxVnGHrgeTlOuIkdD4imtx/B+qKNhzThOLF8xJE5D+4ohT2k9MLwZGD4ADG8Ghg8Aw5uB4QPINRxqdH14J9awmyG7summ5tfqJthQO1NY21wtUrKh7zJW9mqWTLLhcPDV9INYQ6XHqhXGXaqcXEM1L2/4S2k5qYbaNfP61LXEnFRDpWhJize/MIbrEAau1E6qoV75FfZKwlqmoVYmWiWmUp1ex5VpqKIQdhdkOG9/l2EcwuDYnu4UZRrq7frihSVOgYahKm2xUzw9eBNoqJy3O8Pi9CRDoqGqhv0+UQzpbKco0bAs9iEMVOeKlGeoVWpH0bnBmzxD5VMbbuhUJQUapkJI9tR5Ks+w+bBnqnRxXqr7razMx30d8gzTu4nI1nE1O8HWfkl0SDN0TXq7lKUwyYgqqrvDw9uftq1JM9RftoP57eF09PYaYYbOpNRG6vUIXLtqrH6bPk+FGX4LYdcpLripVSJbupSjMMNvISyiwZsu5sFdOlsly1Afa8Xn6Xzw9N96geTAXJShazMMi3I4WOsmejtlIMowbws4jRmbOOA2tV1dkGFoGbMMu9O0q24VZzpSSziCDKfttV8iSGOSv9wODRKjVkGGrs7Z/G0b1w/XdDy6Cz/b8rBIQYal3U7sj6j70WhoR+12AEt02CVKMdTpWVNk0TeZ4as5SgM0R8NTIYZDnTMYL7bjjpOO8uJCDFVeCKebX1Kt7tEcQ4xhXgjH/dPJgw96DCmGuyz3MdQ1pc4nj632QRRi+HXWNNJNghvz4cPwO0Uhht9nTeMfhqp+PGCf0BBimBnC8a8/fRzNdpFKhmFuCDOoZcYwa9aUyXZFXIThrTfO0qbHeN1QL+/exKbHeN1QZc6a8tnMMV431GHWdPM9s3W07/Z1Q+XKgxXfS8RZqfcN84bcP4LW6zfvG2YOuX9EGwavk9HrhvqBEEYbNt82/LTWdIFVVuptwweuwp6l23/bUD/zHJfVbsa3Df3nmcJpltP0bcPwziNR9GJaGqUbU91LG1g9BeN9w2v3GiSR0x8+9AAQSWOap4Hhzfx6Q1eNzxdiKU1F6yFshn0ILdPjcPoUCU2GLGVOeVG2p4u5aZWK68Lw/Vkavswdt/jmFDiN7A9WNB5hSf3WhoPpFKXrd9tmCi63irA8sI3mb+f2F58xvDF/n6VIwytXCFW/2Y7zyZ6TJVv3pPpnxPGzW655Ere9a+tpqLAVp2D/BNOa1TG54+1JfMXW4JDhDeCM9r5kwL+k92d4/vNFBAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAD4Y/wDpoY2HBKwqLIAAAAASUVORK5CYII=" alt="your image" style="width:70px; height:70px; margin: 17px 0 0 0;"/></a>								
                            </div>
                            
                           
							<hr/>
							<div class="row">			
							<div class="col-md-12">
							<div id="body">		
									<div id="container">
									<div id="filelist"></div>
									<div id="file_link" class="text-center text-danger h5"></div>
										<div class="form-group col-md-3">
											<a id="uploadFile" class="fa fa-file" name="uploadFile" href="javascript:;">Select Videos here</a>
										</div>

										<div class="form-group col-md-8">
											<a id="upload" href="javascript:;" class="fa fa-upload">Upload files</a>
										</div>
									</div>									
									<input type="hidden" id="file_ext" name="file_ext" value="<?=substr( md5( rand(10,100) ) , 0 ,10 )?>">
									<div id="console"></div>									
									<input type="hidden" name="file_name" id="file_name" />
								</div>
								
							</div>
							</span>
							</div>
						<hr/>	
							
							<div class="row">
                               <div class="col-md-6">
                                    <div class="form-group">                                        
                                        <label for="status">Status</label>
                                        <select class="form-control required" id="status" name="status">
                                            <option value="" >--Select--</option>
											<option value="1" <?php if($status == 1){echo "selected";}?>>Active</option>
                                            <option value="2" <?php if($status == 2){echo "selected";}?>>InActive</option>
                                        </select>
                                    </div>                                
                                </div>   								
                            </div>
							
							
                            
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="submit" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-default" value="Reset" />
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-md-4">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');
                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row">
                    <div class="col-md-12">
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
        </div>    
    </section>
</div>
<script type="text/javascript">
	BASE_URL = "<?php echo base_url();?>"
</script>
<script src="<?=base_url();?>public/js/plupload/plupload.full.min.js"></script>
<script type="text/javascript" src="<?=base_url();?>public/js/application.js"></script>
<script src="<?php echo base_url(); ?>assets/js/addVideo.js" type="text/javascript"></script>