<?php if(!defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Class : Video_model (Video Model)
 * User model class to get to handle user related data 
 * @author : Just Cool Down
 * @version : 1.1
 * @since : 15 November 2016
 */
class Video_model extends CI_Model
{
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @return number $count : This is row count
     */
    function videoListingCount($searchText = '')
    {
        $this->db->select('BaseTbl.id as videoId, BaseTbl.title, BaseTbl.image_url, BaseTbl.status, BaseTbl.createdDtm');
        $this->db->from('tbl_videos as BaseTbl');        
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.title  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
		$this->db->where('BaseTbl.isDeleted', 0);
        $query = $this->db->get();        
        return $query->num_rows();
    }
    
    /**
     * This function is used to get the user listing count
     * @param string $searchText : This is optional search text
     * @param number $page : This is pagination offset
     * @param number $segment : This is pagination limit
     * @return array $result : This is result
     */
    function videoListing($searchText = '', $page, $segment)
    {
        $this->db->select('BaseTbl.id as videoId, BaseTbl.title, BaseTbl.image_url, BaseTbl.status, BaseTbl.createdDtm');
        $this->db->from('tbl_videos as BaseTbl');        
        if(!empty($searchText)) {
            $likeCriteria = "(BaseTbl.title  LIKE '%".$searchText."%')";
            $this->db->where($likeCriteria);
        }
        $this->db->where('BaseTbl.isDeleted', 0);
        $this->db->order_by('BaseTbl.id', 'DESC');
        $this->db->limit($page, $segment);
        $query = $this->db->get();
        
        $result = $query->result();        
        return $result;
    }

    /**
     * This function is used to add new user to system
     * @return number $insert_id : This is last inserted id
     */
    function addNewVideo($videoInfo)
    {
        $this->db->trans_start();
        $this->db->insert('tbl_videos', $videoInfo);
        
        $insert_id = $this->db->insert_id();
        
        $this->db->trans_complete();
        
        return $insert_id;
    }
    
    /**
     * This function used to get user information by id
     * @param number $userId : This is user id
     * @return array $result : This is user information
     */
    function getVideoInfo($userId)
    {
        $this->db->select('id as videoId, title, image_url, video_url, status');
        $this->db->from('tbl_videos');     
		$this->db->where('isDeleted', 0);		
        $this->db->where('id', $userId);
        $query = $this->db->get();
        
        return $query->row();
    }
    
    
    /**
     * This function is used to update the user information
     * @param array $userInfo : This is users updated information
     * @param number $userId : This is user id
     */
    function editVideo($videoInfo, $videoId)
    {
        $this->db->where('id', $videoId);
        $this->db->update('tbl_videos', $videoInfo);
        
        return TRUE;
    }
    
    
    
    /**
     * This function is used to delete the user information
     * @param number $userId : This is user id
     * @return boolean $result : TRUE / FALSE
     */
    function deleteVideo($videoId, $videoInfo)
    {
        $this->db->where('id', $videoId);
        $this->db->update('tbl_videos', $videoInfo);
        
        return $this->db->affected_rows();
    }

}

  