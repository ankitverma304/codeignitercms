/**
 * File : addVideo.js
 * 
 * This file contain the validation of add user form
 * 
 * Using validation plugin : jquery.validate.js
 * 
 * @author Just Cool Down
 */

$(document).ready(function(){
	
	var addVideoForm = $("#addVideo");
	
	var validator = addVideoForm.validate({
		
		rules:{
			title :{ required : true },			
			status : { required : true, selected : true}
		},
		messages:{
			title :{ required : "This field is required" },			
			status : { required : "This field is required", selected : "Please select atleast one option" }			
		}
	});
	
	var editVideoForm = $("#editVideo");
	
	var validator = editVideoForm.validate({
		
		rules:{
			title :{ required : true },			
			status : { required : true, selected : true}
		},
		messages:{
			title :{ required : "This field is required" },			
			status : { required : "This field is required", selected : "Please select atleast one option" }			
		}
	});
});
